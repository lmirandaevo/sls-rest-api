
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'lmiranda',
  applicationName: 'notes',
  appUid: 'wMgVl1GQCDYHq5RRt9',
  orgUid: '00f4ad9d-c4da-4bdf-bbb4-5b6022df34ef',
  deploymentUid: 'cc0c2031-f1fc-4799-97a8-6621fbbd1ef0',
  serviceName: 'notes-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'notes-api-dev-createNote', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.createNote, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}